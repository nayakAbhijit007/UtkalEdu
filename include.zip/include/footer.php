  <!-- ==================== Footer Area (Start) ==================== -->
  <footer class="footer">

    <div class="box-container">

      <!-- <div class="footer-item">
        Logo 
        <a class="logo" href="index-2.html">
          <img src="assets/images/Logo/Logo.png" alt="logo">
          <div class="logo-name">
            <h3>Siraj</h3>
            <p>islamic center</p>
          </div>
        </a>
        <p>We teach, model, and encourage a love of learning and combine Quranic teachings with Computer Science and other modern disciplines.</p>
      </div> -->

      <div class="footer-item">
        <h2>Notice & News</h2>
        <div class="info links">
          <p><a href="pages/Services/Service-Details.html">OFFICE WORKING HOUR : November 25, 2020</a></p>
          <p><a href="pages/Services/Service-Details.html">OFFICE WORKING HOUR :  May 23, 2020</a></p>
          <p><a href="pages/Services/Service-Details.html">REGARDING 2ND SEM PRACTICAL FOR B.Ed STUDENTS : May 23, 2020</a></p>
          <p><a href="pages/Services/Service-Details.html"> ADMISSION OPEN :  May 15, 2020</a></p>
          <p><a href="pages/Services/Service-Details.html">ADMISSION OPEN :   May 15, 2020</a></p>
          <!-- <p><a href="pages/Services/Service-Details.html">Funeral Service</a></p> -->
        </div>
      </div>

      <div class="footer-item">
        <h2>Quick Link</h2>
        <div class="info links pages">
          <div class="links-item">
            <p><a href="index-2.html">home</a></p>
            <p><a href="pages/About/About.html">about</a></p>
            <p><a href="pages/Services/Services.html">course</a></p>
            <p><a href="pages/Causes/Causes.html">student corner</a></p>
            <p><a href="pages/Events/Events.html">recognition</a></p>
            <!-- <p><a href="pages/Events/Events.html">gallery</a></p>
            <p><a href="pages/Events/Events.html">contact us</a></p> -->
          </div>
          <div class="links-item">
            <p><a href="pages/Pages/Gallery.html">gallery</a></p>
            <p><a href="pages/Events/Events.html">admission</a></p>
            <!-- <p><a href="pages/Blog/Blog-Grid.html">blogs</a></p> -->
            <p><a href="pages/Events/Events.html">franchise</a></p>
            <p><a href="pages/Shop/Shop-Grid.html">shop</a></p>
            <p><a href="pages/Contact/contact.html">contact</a></p>
          </div>
        </div>
      </div> 

      <div class='footer-item'>
        <h2>Contact Us</h2> 
        <div class="info">
        <p><i style="margin-top: -2rem;" class="fas fa-location-dot"></i><span>Plot No-409, Bomikhal, Rasulgarh, Bhubaneshwar - 751010, Opposite Esplanade Mall</span></p>
        <p><i class="fas fa-phone"></i><span>+91 9556941153</span></p>
          <p><i class="fas fa-phone"></i><span>+91 8093719253</span></p>
          <p><i class="fas fa-envelope"></i><span class="gmail"><a href="cdn-cgi/l/email-protection.html" class="__cf_email__">utkaleducation123@gmailcom</a></span></p>
          <!-- <p><i class="fas fa-envelope"></i><span class="gmail"><a href="cdn-cgi/l/email-protection.html" class="__cf_email__" data-cfemail="740c0d0e341319151d185a171b19">[email&#160;protected]</a></span></p>
          <p><i class="fas fa-map"></i><span>karachi, pakistan</span></p> -->
        </div>
        <!-- <div class="social">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-linkedin"></i></a>
        </div> -->
      </div>

    </div>

    <div class="content">
        <p>Designed & Devloped By <span>Cloudedge Technology.</span></p>
    </div>

  </footer>
  <!-- ==================== Footer Area (End) ==================== -->



  <!-- Jquery -->
  <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/vendors/jquery/jquery-3.6.0.js"></script>

  <!-- Magnific-Popup JS -->
  <script src="assets/vendors/magnific-popup/jquery.magnific-popup.js"></script>

  <!-- Swiper (JS) -->
  <script src="assets/vendors/swiper/swiper.js"></script>

  <!-- Custom Script Files -->
  <script src="assets/js/script.js"></script>
  <script src="assets/js/nav-link-toggler.js"></script>
  <script src="assets/js/home-slider.js"></script>
  <script src="assets/js/gallery.js"></script>
  <script src="assets/js/counter-up.js"></script>
  <script src="assets/js/testi-slider.js"></script>

</body>

<!-- Mirrored from siraj-html.astemplatedesigns.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 05 Jan 2023 11:58:11 GMT -->
</html>